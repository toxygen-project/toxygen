var searchData=
[
  ['get_5fcorr_5ffor_5fsaving',['get_corr_for_saving',['../classsrc_1_1profile_1_1Friend.html#a67e773319eb8efc8ea39ccf3b95f9fa7',1,'src::profile::Friend']]],
  ['get_5fsavedata',['get_savedata',['../classsrc_1_1tox_1_1Tox.html#a425fa565f83b47e768adc35b744fd099',1,'src::tox::Tox']]],
  ['get_5fsavedata_5fsize',['get_savedata_size',['../classsrc_1_1tox_1_1Tox.html#a01ad4f7b25d01f88f0a1a49aa6351a4f',1,'src::tox::Tox']]]
];
