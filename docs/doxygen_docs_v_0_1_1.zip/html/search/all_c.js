var searchData=
[
  ['options_5fdefault',['options_default',['../classsrc_1_1tox_1_1Tox.html#a06383db722ff5f011ee0bee3af5a6268',1,'src::tox::Tox']]],
  ['options_5ffree',['options_free',['../classsrc_1_1tox_1_1Tox.html#a12ea9c1a58acc4b1fd64b3d54e8c51d2',1,'src::tox::Tox']]],
  ['options_5fnew',['options_new',['../classsrc_1_1tox_1_1Tox.html#af309d32e93080b3b8327bc0345a73916',1,'src::tox::Tox']]]
];
