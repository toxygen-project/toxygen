var searchData=
[
  ['reset',['reset',['../classsrc_1_1main_1_1Toxygen.html#aa77ea39deb7371f6b644037103e1495d',1,'src.main.Toxygen.reset()'],['../classsrc_1_1profile_1_1Profile.html#ae8396c7e5303a9dca381c302005f452d',1,'src.profile.Profile.reset()']]]
];
