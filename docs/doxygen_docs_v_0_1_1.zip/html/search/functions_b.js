var searchData=
[
  ['new_5fmessage',['new_message',['../classsrc_1_1profile_1_1Profile.html#a8496fdc5b22f19b6439e242b705fd272',1,'src::profile::Profile']]]
];
